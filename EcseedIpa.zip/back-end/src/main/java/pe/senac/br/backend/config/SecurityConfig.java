package pe.senac.br.backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration; // Importação correta para AuthenticationManager
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // Configuração de segurança geral 
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 1. Desabilita CSRF (Substitui .csrf().disable())
            .csrf(csrf -> csrf.disable())

            // 2. Configuração de autorização de requisições (Substitui .authorizeRequests() e .antMatchers())
            .authorizeHttpRequests(authorize -> authorize
                .requestMatchers("/login", "/register").permitAll() // Usa requestMatchers
                .anyRequest().authenticated()
            )
            // 3. Configuração de login com formulário (Substitui .and().formLogin())
            .formLogin(form -> form
                .loginPage("/login")
                .permitAll()
            )
            // 4. Configuração de logout (Substitui .and().logout())
            .logout(logout -> logout
                .permitAll()
            );

        return http.build();
    }

    
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
}