package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.model.EnderecoCooperativa;
import pe.senac.br.backend.repository.EnderecoCooperativaRepository;

import java.util.List;

@Service
public class EnderecoCooperativaService {

    @Autowired
    private EnderecoCooperativaRepository repo;

    public List<EnderecoCooperativa> listarTodos() {
        return repo.findAll();
    }

    public EnderecoCooperativa buscarPorId(Integer id) {
        return repo.findById(id).orElse(null);
    }

    public EnderecoCooperativa salvar(EnderecoCooperativa endereco) {
        return repo.save(endereco);
    }

    public EnderecoCooperativa atualizar(Integer id, EnderecoCooperativa dados) {

        EnderecoCooperativa existente = buscarPorId(id);
        if (existente == null) return null;

        existente.setRua(dados.getRua());
        existente.setNumero(dados.getNumero());
        existente.setCidade(dados.getCidade());
        existente.setUf(dados.getUf());
        existente.setCooperativa(dados.getCooperativa()); // se quiser atualizar a cooperativa associada

        return repo.save(existente);
    }

    public boolean deletar(Integer id) {
        EnderecoCooperativa existente = buscarPorId(id);
        if (existente == null) return false;

        repo.delete(existente);
        return true;
    }
}
