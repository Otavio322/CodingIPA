package pe.senac.br.backend.service;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Crie sua lógica para buscar o usuário, aqui é apenas um exemplo
        if ("admin".equals(username)) {
            return User.withUsername(username)
                       .password("{noop}password") // Usando {noop} para senha em texto simples
                       .roles("USER")
                       .build();
        }
        throw new UsernameNotFoundException("User not found");
    }
}
