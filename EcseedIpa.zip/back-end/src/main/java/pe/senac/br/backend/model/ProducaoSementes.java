package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "producao_sementes")
public class ProducaoSementes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producao_sementes")
    private Integer id;

    @Column(name = "tipo_semente")
    private String tipoSemente;

    @Column(name = "quantidade_sementes")
    private Integer quantidadeSementes;

    private Double preco;

    private LocalDate validade;

    // Relacionamento Many-to-Many com Agricultores
    @ManyToMany(mappedBy = "producoes")
    private Set<Agricultores> produtores = new HashSet<>();

    // Getters and Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTipoSemente() { return tipoSemente; }
    public void setTipoSemente(String tipoSemente) { this.tipoSemente = tipoSemente; }

    public Integer getQuantidadeSementes() { return quantidadeSementes; }
    public void setQuantidadeSementes(Integer quantidadeSementes) { this.quantidadeSementes = quantidadeSementes; }

    public Double getPreco() { return preco; }
    public void setPreco(Double preco) { this.preco = preco; }

    public LocalDate getValidade() { return validade; }
    public void setValidade(LocalDate validade) { this.validade = validade; }

    public Set<Agricultores> getProdutores() { return produtores; }
    public void setProdutores(Set<Agricultores> produtores) { this.produtores = produtores; }
}
