package pe.senac.br.backend.dto;

import java.time.LocalDateTime;

public class EntradaSementesDTO {

    private Integer idEntradaSementes;
    private String tipoSemente;
    private Integer quantidadeSementes;
    private LocalDateTime dataChegada;
    private String ipaCnpj;  

    // Construtor
    public EntradaSementesDTO(Integer idEntradaSementes, String tipoSemente, Integer quantidadeSementes,
                              LocalDateTime dataChegada, String ipaCnpj) {
        this.idEntradaSementes = idEntradaSementes;
        this.tipoSemente = tipoSemente;
        this.quantidadeSementes = quantidadeSementes;
        this.dataChegada = dataChegada;
        this.ipaCnpj = ipaCnpj;
    }

    // Getters e Setters
    public Integer getIdEntradaSementes() {
        return idEntradaSementes;
    }

    public void setIdEntradaSementes(Integer idEntradaSementes) {
        this.idEntradaSementes = idEntradaSementes;
    }

    public String getTipoSemente() {
        return tipoSemente;
    }

    public void setTipoSemente(String tipoSemente) {
        this.tipoSemente = tipoSemente;
    }

    public Integer getQuantidadeSementes() {
        return quantidadeSementes;
    }

    public void setQuantidadeSementes(Integer quantidadeSementes) {
        this.quantidadeSementes = quantidadeSementes;
    }

    public LocalDateTime getDataChegada() {
        return dataChegada;
    }

    public void setDataChegada(LocalDateTime dataChegada) {
        this.dataChegada = dataChegada;
    }

    public String getIpaCnpj() {
        return ipaCnpj;
    }

    public void setIpaCnpj(String ipaCnpj) {
        this.ipaCnpj = ipaCnpj;
    }
}
