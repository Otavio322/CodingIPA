package pe.senac.br.backend.dto;

public class EnderecoCooperativaDTO {

    private Integer id;
    private String CNPJ;
    private String rua;
    private String numero;
    private String cidade;
    private String uf;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getCNPJ() { return CNPJ; }
    public void setCNPJ(String CNPJ) { this.CNPJ = CNPJ; }

    public String getRua() { return rua; }
    public void setRua(String rua) { this.rua = rua; }

    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }

    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }

    public String getUf() { return uf; }
    public void setUf(String uf) { this.uf = uf; }
}
