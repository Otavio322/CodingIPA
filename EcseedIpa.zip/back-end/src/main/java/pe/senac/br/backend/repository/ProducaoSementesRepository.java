package pe.senac.br.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.senac.br.backend.model.ProducaoSementes;

@Repository
public interface ProducaoSementesRepository extends JpaRepository<ProducaoSementes, Integer> {
    
}