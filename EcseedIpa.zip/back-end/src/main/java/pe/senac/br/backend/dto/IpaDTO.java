package pe.senac.br.backend.dto;

public class IpaDTO {

    private String CNPJIPA;  
    private String Nome;     
    private String Telefone;
    private String Email;    

    // Construtor
    public IpaDTO(String CNPJIPA, String Nome, String Telefone, String Email) {
        this.CNPJIPA = CNPJIPA;
        this.Nome = Nome;
        this.Telefone = Telefone;
        this.Email = Email;
    }

    // Getters e Setters
    public String getCNPJIPA() {
        return CNPJIPA;
    }

    public void setCNPJIPA(String CNPJIPA) {
        this.CNPJIPA = CNPJIPA;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
