package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.model.TransporteSementes;
import pe.senac.br.backend.service.TransporteSementesService;

import java.util.List;

@RestController
@RequestMapping("/api/transporte")
@CrossOrigin("*")
public class TransporteSementesController {

    @Autowired
    private TransporteSementesService TransporteService;

    // LISTAR TODOS
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<TransporteSementes> listarTodos() {
        return TransporteService.listarTodos();
    }

    // BUSCAR POR ID
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TransporteSementes> buscarPorId(@PathVariable Integer id) {
        TransporteSementes transporte = TransporteService.buscarPorId(id);
        return ResponseEntity.ok(transporte);
    }

    // CRIAR TRANSPORTE
    @PostMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<TransporteSementes> criar(@RequestBody TransporteSementes transporte) {
        TransporteSementes novo = TransporteService.criarTransporte(transporte);
        return ResponseEntity.status(201).body(novo);
    }

    // ATUALIZAR
    @PutMapping(
            value = "/{id}",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<TransporteSementes> atualizar(
            @PathVariable Integer id,
            @RequestBody TransporteSementes transporte) {

        TransporteSementes atualizado = TransporteService.atualizar(id, transporte);
        return ResponseEntity.ok(atualizado);
    }

    // DELETAR
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Integer id) {
        boolean apagado = TransporteService.deletar(id);
        return apagado ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}