package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.model.TransporteSementes;
import pe.senac.br.backend.service.TransporteSementesService;

import java.util.List;

@RestController
@RequestMapping("/api/transporte")

@CrossOrigin(origins = "http://localhost:3000") 
public class TransporteSementesController {

    @Autowired
    private TransporteSementesService service;

    @GetMapping
    public List<TransporteSementes> listar() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransporteSementes> buscar(@PathVariable Integer id) {
        TransporteSementes t = service.buscarPorId(id);
        return t != null ? ResponseEntity.ok(t) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<TransporteSementes> criar(@RequestBody TransporteSementes transporte) {
        TransporteSementes novo = service.criarTransporte(transporte);
        return ResponseEntity.status(201).body(novo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TransporteSementes> atualizar(@PathVariable Integer id, @RequestBody TransporteSementes transporte) {
        TransporteSementes atualizado = service.atualizar(id, transporte);
        return atualizado != null ? ResponseEntity.ok(atualizado) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Integer id) {
        return service.deletar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}