package pe.senac.br.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.senac.br.backend.model.Transportadora;

public interface TransportadoraRepository extends JpaRepository<Transportadora, Integer> {
}
