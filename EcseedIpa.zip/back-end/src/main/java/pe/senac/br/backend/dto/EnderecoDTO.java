package pe.senac.br.backend.dto;

public class EnderecoDTO {

    private Integer idEndereco;
    private String rua;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;

    public EnderecoDTO(Integer idEndereco, String rua, String bairro, String cidade, String estado, String cep) {
        this.idEndereco = idEndereco;
        this.rua = rua;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }

    public Integer getIdEndereco() {
        return idEndereco;
    }

    public String getRua() {
        return rua;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public String getEstado() {
        return estado;
    }

    public String getCep() {
        return cep;
    }
}
