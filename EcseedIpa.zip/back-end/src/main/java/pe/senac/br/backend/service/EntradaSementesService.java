package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.dto.EntradaSementesDTO;
import pe.senac.br.backend.model.EntradaSementes;
import pe.senac.br.backend.repository.EntradaSementesRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EntradaSementesService {

    @Autowired
    private EntradaSementesRepository entradaSementesRepository;

    public List<EntradaSementesDTO> getAllEntradaSementes() {
        return entradaSementesRepository.findAll().stream()
                .map(es -> new EntradaSementesDTO(
                        es.getIdEntradaSementes(),
                        es.getTipoSemente(),
                        es.getQuantidadeSementes(),
                        es.getDataChegada(),
                        es.getIpa().getCnpj()   
                ))
                .collect(Collectors.toList());
    }

    public Optional<EntradaSementesDTO> getEntradaSementesById(Integer id) {
        return entradaSementesRepository.findById(id)
                .map(es -> new EntradaSementesDTO(
                        es.getIdEntradaSementes(),
                        es.getTipoSemente(),
                        es.getQuantidadeSementes(),
                        es.getDataChegada(),
                        es.getIpa().getCnpj()   
                ));
    }

    public EntradaSementesDTO createEntradaSementes(EntradaSementes entradaSementes) {
        EntradaSementes saved = entradaSementesRepository.save(entradaSementes);
        return new EntradaSementesDTO(
                saved.getIdEntradaSementes(),
                saved.getTipoSemente(),
                saved.getQuantidadeSementes(),
                saved.getDataChegada(),
                saved.getIpa().getCnpj()   
        );
    }

    public Optional<EntradaSementesDTO> updateEntradaSementes(Integer id, EntradaSementes entradaSementes) {
        if (entradaSementesRepository.existsById(id)) {
            entradaSementes.setIdEntradaSementes(id);
            EntradaSementes updated = entradaSementesRepository.save(entradaSementes);
            return Optional.of(new EntradaSementesDTO(
                    updated.getIdEntradaSementes(),
                    updated.getTipoSemente(),
                    updated.getQuantidadeSementes(),
                    updated.getDataChegada(),
                    updated.getIpa().getCnpj()   
            ));
        }
        return Optional.empty();
    }

    public boolean deleteEntradaSementes(Integer id) {
        if (entradaSementesRepository.existsById(id)) {
            entradaSementesRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
