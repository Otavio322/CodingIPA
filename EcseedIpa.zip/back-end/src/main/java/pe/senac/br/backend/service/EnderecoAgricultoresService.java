package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.model.EnderecoAgricultores;
import pe.senac.br.backend.repository.EnderecoAgricultoresRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EnderecoAgricultoresService {

    @Autowired
    private EnderecoAgricultoresRepository repository;

    public List<EnderecoAgricultores> listarTodos() {
        return repository.findAll();
    }

    public Optional<EnderecoAgricultores> buscarPorId(String cpfCnpjAgricultor) {
        return repository.findById(cpfCnpjAgricultor);
    }

    public EnderecoAgricultores salvar(EnderecoAgricultores endereco) {
        return repository.save(endereco);
    }

    public EnderecoAgricultores atualizar(String cpfCnpj, EnderecoAgricultores enderecoAtualizado) {
        return repository.findById(cpfCnpj).map(endereco -> {

            endereco.setLogradouro(enderecoAtualizado.getLogradouro());
            endereco.setNumero(enderecoAtualizado.getNumero());
            endereco.setBairro(enderecoAtualizado.getBairro());
            endereco.setCidade(enderecoAtualizado.getCidade());
            endereco.setEstado(enderecoAtualizado.getEstado());
            endereco.setCep(enderecoAtualizado.getCep());
            endereco.setAgricultor(enderecoAtualizado.getAgricultor());

            return repository.save(endereco);

        }).orElse(null);
    }

    public boolean deletar(String cpfCnpj) {
        return repository.findById(cpfCnpj).map(endereco -> {
            repository.delete(endereco);
            return true;
        }).orElse(false);
    }
}
