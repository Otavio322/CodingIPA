package pe.senac.br.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "endereco_agricultor")
public class EnderecoAgricultores {

    @Id
    @Column(name = "cpf_cnpj_agricultor")
    private String cpfCnpjAgricultor;

    private String bairro;
    private String cep;
    private String cidade;
    private String estado;
    private String logradouro;
    private String numero;

    @OneToOne
    @MapsId   
    @JoinColumn(name = "cpf_cnpj_agricultor")
    private Agricultores agricultor;

    // GETTERS e SETTERS

    public String getCpfCnpjAgricultor() { return cpfCnpjAgricultor; }
    public void setCpfCnpjAgricultor(String cpfCnpjAgricultor) { this.cpfCnpjAgricultor = cpfCnpjAgricultor; }

    public String getBairro() { return bairro; }
    public void setBairro(String bairro) { this.bairro = bairro; }

    public String getCep() { return cep; }
    public void setCep(String cep) { this.cep = cep; }

    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getLogradouro() { return logradouro; }
    public void setLogradouro(String logradouro) { this.logradouro = logradouro; }

    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }

    public Agricultores getAgricultor() { return agricultor; }
    public void setAgricultor(Agricultores agricultor) {
        this.agricultor = agricultor;
        if (agricultor != null) {
            this.cpfCnpjAgricultor = agricultor.getCpfCnpj();
        }
    }
}
