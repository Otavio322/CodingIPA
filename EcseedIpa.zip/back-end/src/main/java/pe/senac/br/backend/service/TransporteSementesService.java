package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.model.TransporteSementes;
import pe.senac.br.backend.repository.TransporteSementesRepository;

import java.util.List;

@Service
public class TransporteSementesService {

    @Autowired
    private TransporteSementesRepository repo;

    public List<TransporteSementes> listarTodos() {
        return repo.findAll();
    }

    public TransporteSementes buscarPorId(Integer id) {
        return repo.findById(id).orElse(null);
    }

    public TransporteSementes criarTransporte(TransporteSementes transporte) {
        
        if (transporte.getStatusTransporte() == null || transporte.getStatusTransporte().trim().isEmpty()) {
            transporte.setStatusTransporte("PENDENTE");
        }
        return repo.save(transporte);
    }

    public TransporteSementes atualizar(Integer id, TransporteSementes novo) {
        return repo.findById(id).map(existente -> {
            existente.setOrigem(novo.getOrigem());
            existente.setDestino(novo.getDestino());
            existente.setQuantidade(novo.getQuantidade());
            existente.setDataEnvio(novo.getDataEnvio());
            existente.setDataEntregaPrevista(novo.getDataEntregaPrevista());
            existente.setStatusTransporte(novo.getStatusTransporte());
            
            return repo.save(existente);
        }).orElse(null);
    }

    public boolean deletar(Integer id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }
}