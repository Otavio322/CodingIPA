package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.model.TransporteSementes;
import pe.senac.br.backend.repository.TransporteSementesRepository;

import java.util.List;

@Service
public class TransporteSementesService {

    @Autowired
    private TransporteSementesRepository transporteRepo;

    // LISTAR TODOS
    public List<TransporteSementes> listarTodos() {
        return transporteRepo.findAll();
    }

    // BUSCAR POR ID
    public TransporteSementes buscarPorId(Integer id) {
        return transporteRepo.findById(id).orElse(null);
    }

    // CRIAR
    public TransporteSementes criarTransporte(TransporteSementes transporte) {

        // valores padrão
        transporte.setStatusTransporte("AGENDADO");
        transporte.setDataEntregaPrevista("PENDENTE");

        return transporteRepo.save(transporte);
    }

    // ATUALIZAR
    public TransporteSementes atualizar(Integer id, TransporteSementes novo) {

        TransporteSementes existente = buscarPorId(id);

        if (existente == null) {
            return null;
        }

        existente.setOrigem(novo.getOrigem());
        existente.setDestino(novo.getDestino());
        existente.setQuantidade(novo.getQuantidade());
        existente.setDataEnvio(novo.getDataEnvio());
        existente.setDataEntregaPrevista(novo.getDataEntregaPrevista());
        existente.setStatusTransporte(novo.getStatusTransporte());

        // mantém MANY-TO-MANY (se vier no JSON)
        existente.setAgricultores(novo.getAgricultores());
        existente.setTransportadora(novo.getTransportadora());

        return transporteRepo.save(existente);
    }

    // DELETAR
    public boolean deletar(Integer id) {

        if (!transporteRepo.existsById(id)) {
            return false;
        }

        transporteRepo.deleteById(id);
        return true;
    }
}
