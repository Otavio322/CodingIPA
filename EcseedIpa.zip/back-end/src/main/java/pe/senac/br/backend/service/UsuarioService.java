package pe.senac.br.backend.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.senac.br.backend.model.Usuario;
import pe.senac.br.backend.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public boolean authenticate(String cpfCnpj, String senha) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByCpfCnpj(cpfCnpj);

        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            return senha.equals(usuario.getSenha()); // Comparação simples sem criptografia
        }

        return false;
    }
}
