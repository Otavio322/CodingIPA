package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.AgricultoresDTO;
import pe.senac.br.backend.model.Agricultores;
import pe.senac.br.backend.service.AgricultoresService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/agricultores")
@CrossOrigin(origins = "http://localhost:3000")
public class AgricultoresController {

    @Autowired
    private AgricultoresService agricultoresService;

    @GetMapping
    public List<AgricultoresDTO> getAllAgricultores() {
        return agricultoresService.getAllAgricultores();
    }

    @GetMapping("/{cpfCnpj}")
    public ResponseEntity<AgricultoresDTO> getAgricultorByCPF_CNPJ(@PathVariable String cpfCnpj) {
        Optional<AgricultoresDTO> agricultor = agricultoresService.getAgricultorByCPF_CNPJ(cpfCnpj);
        return agricultor.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<AgricultoresDTO> createAgricultor(@RequestBody Agricultores agricultor) {
        AgricultoresDTO createdAgricultor = agricultoresService.createAgricultor(agricultor);
        return ResponseEntity.status(201).body(createdAgricultor);
    }

    @PutMapping("/{cpfCnpj}")
    public ResponseEntity<AgricultoresDTO> updateAgricultor(@PathVariable String cpfCnpj, @RequestBody Agricultores agricultor) {
        Optional<AgricultoresDTO> updatedAgricultor = agricultoresService.updateAgricultor(cpfCnpj, agricultor);
        return updatedAgricultor.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{cpfCnpj}")
    public ResponseEntity<Void> deleteAgricultor(@PathVariable String cpfCnpj) {
        boolean isDeleted = agricultoresService.deleteAgricultor(cpfCnpj);
        return isDeleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}