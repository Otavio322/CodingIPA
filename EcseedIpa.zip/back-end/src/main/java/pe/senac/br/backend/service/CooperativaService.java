package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.model.Cooperativa;
import pe.senac.br.backend.repository.CooperativaRepository;

import java.util.List;

@Service
public class CooperativaService {

    @Autowired
    private CooperativaRepository cooperativaRepository;

    // LISTAR TODAS
    public List<Cooperativa> listarTodas() {
        return cooperativaRepository.findAll();
    }

    // BUSCAR POR CNPJ
    public Cooperativa buscarPorCNPJ(String cnpj) {
        return cooperativaRepository.findById(cnpj).orElse(null);
    }

    // SALVAR
    public Cooperativa salvar(Cooperativa cooperativa) {
        return cooperativaRepository.save(cooperativa);
    }

    // ATUALIZAR
    public Cooperativa atualizar(String cnpj, Cooperativa dados) {
        Cooperativa existente = buscarPorCNPJ(cnpj);

        if (existente == null) {
            return null;
        }

        existente.setNome(dados.getNome());
        existente.setEmail(dados.getEmail());
        existente.setTelefone(dados.getTelefone());

        return cooperativaRepository.save(existente);
    }

    // DELETAR
    public boolean deletar(String cnpj) {
        Cooperativa existente = buscarPorCNPJ(cnpj);

        if (existente == null) {
            return false;
        }

        cooperativaRepository.delete(existente);
        return true;
    }
}
