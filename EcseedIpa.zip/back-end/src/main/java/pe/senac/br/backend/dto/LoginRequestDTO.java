package pe.senac.br.backend.dto;
import pe.senac.br.backend.dto.LoginRequestDTO;
public class LoginRequestDTO {
    private String cpfCnpj;
    private String senha;

    // Getters e Setters
    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}