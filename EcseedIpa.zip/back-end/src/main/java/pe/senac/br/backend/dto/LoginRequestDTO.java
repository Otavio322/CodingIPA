package pe.senac.br.backend.dto;

public class LoginRequestDTO {
    private String cpfCnpj;
    private String senha;

    // Getters e Setters
    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
