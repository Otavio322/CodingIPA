package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.dto.IpaDTO;
import pe.senac.br.backend.model.Ipa;
import pe.senac.br.backend.repository.IpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class IpaService {

    @Autowired
    private IpaRepository ipaRepository;

    private IpaDTO toDTO(Ipa ipa) {
        return new IpaDTO(
                ipa.getCnpj(),
                ipa.getNome(),
                ipa.getTelefone(),
                ipa.getEmail()
        );
    }

    public List<IpaDTO> getAllIpas() {
        return ipaRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public Optional<IpaDTO> getIpaByCNPJ(String cnpj) {
        return ipaRepository.findById(cnpj).map(this::toDTO);
    }

    public IpaDTO createIpa(Ipa ipa) {
        Ipa saved = ipaRepository.save(ipa);
        return toDTO(saved);
    }

    public Optional<IpaDTO> updateIpa(String cnpj, Ipa ipa) {
        return ipaRepository.findById(cnpj).map(existing -> {
            existing.setNome(ipa.getNome());
            existing.setTelefone(ipa.getTelefone());
            existing.setEmail(ipa.getEmail());
            return toDTO(ipaRepository.save(existing));
        });
    }

    public boolean deleteIpa(String cnpj) {
        if (ipaRepository.existsById(cnpj)) {
            ipaRepository.deleteById(cnpj);
            return true;
        }
        return false;
    }
}
