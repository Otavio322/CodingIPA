package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.TransportadoraDTO;
import pe.senac.br.backend.model.Transportadora;
import pe.senac.br.backend.service.TransportadoraService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/transportadoras")
public class TransportadoraController {

    @Autowired
    private TransportadoraService transportadoraService;

    // Método GET - Retorna todas as transportadoras
    @GetMapping
    public List<TransportadoraDTO> getAllTransportadoras() {
        return transportadoraService.getAllTransportadoras();
    }

    // Método GET - Retorna uma transportadora pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<TransportadoraDTO> getTransportadoraById(@PathVariable Integer id) {
        Optional<TransportadoraDTO> transportadora = transportadoraService.getTransportadoraById(id);
        return transportadora.map(ResponseEntity::ok)
                             .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Método POST - Cria uma nova transportadora
    @PostMapping
    public ResponseEntity<TransportadoraDTO> createTransportadora(@RequestBody Transportadora transportadora) {
        TransportadoraDTO createdTransportadora = transportadoraService.createTransportadora(transportadora);
        return ResponseEntity.status(201).body(createdTransportadora);
    }

    // Método PUT - Atualiza uma transportadora
    @PutMapping("/{id}")
    public ResponseEntity<TransportadoraDTO> updateTransportadora(@PathVariable Integer id, @RequestBody Transportadora transportadora) {
        Optional<TransportadoraDTO> updatedTransportadora = transportadoraService.updateTransportadora(id, transportadora);
        return updatedTransportadora.map(ResponseEntity::ok)
                                    .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Método DELETE - Deleta uma transportadora
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransportadora(@PathVariable Integer id) {
        boolean isDeleted = transportadoraService.deleteTransportadora(id);
        return isDeleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
