package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.dto.TransportadoraDTO;
import pe.senac.br.backend.model.Transportadora;
import pe.senac.br.backend.repository.TransportadoraRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TransportadoraService {

    @Autowired
    private TransportadoraRepository transportadoraRepository;

    // Retorna todas as transportadoras
    public List<TransportadoraDTO> getAllTransportadoras() {
        return transportadoraRepository.findAll().stream()
                .map(t -> new TransportadoraDTO(
                        t.getIdTransportadora(),
                        t.getNome(),
                        t.getCnpj(),      // ← CORRIGIDO
                        t.getTelefone(),
                        t.getEmail()))
                .collect(Collectors.toList());
    }

    // Retorna uma transportadora pelo ID
    public Optional<TransportadoraDTO> getTransportadoraById(Integer id) {
        return transportadoraRepository.findById(id)
                .map(t -> new TransportadoraDTO(
                        t.getIdTransportadora(),
                        t.getNome(),
                        t.getCnpj(),      // ← CORRIGIDO
                        t.getTelefone(),
                        t.getEmail()));
    }

    // Cria uma nova transportadora
    public TransportadoraDTO createTransportadora(Transportadora transportadora) {
        Transportadora saved = transportadoraRepository.save(transportadora);
        return new TransportadoraDTO(
                saved.getIdTransportadora(),
                saved.getNome(),
                saved.getCnpj(),          // ← CORRIGIDO
                saved.getTelefone(),
                saved.getEmail());
    }

    // Atualiza uma transportadora
    public Optional<TransportadoraDTO> updateTransportadora(Integer id, Transportadora transportadora) {
        if (transportadoraRepository.existsById(id)) {
            transportadora.setIdTransportadora(id);
            Transportadora updated = transportadoraRepository.save(transportadora);

            return Optional.of(new TransportadoraDTO(
                    updated.getIdTransportadora(),
                    updated.getNome(),
                    updated.getCnpj(),     // ← CORRIGIDO
                    updated.getTelefone(),
                    updated.getEmail()));
        }
        return Optional.empty();
    }

    // Deleta uma transportadora
    public boolean deleteTransportadora(Integer id) {
        if (transportadoraRepository.existsById(id)) {
            transportadoraRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
