package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.ProducaoSementesDTO;
import pe.senac.br.backend.model.ProducaoSementes;
import pe.senac.br.backend.service.ProducaoSementesService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/producao-sementes")
public class ProducaoSementesController {

    @Autowired
    private ProducaoSementesService producaoSementesService;

    
    @GetMapping
    public List<ProducaoSementesDTO> getAllProducaoSementes() {
        return producaoSementesService.getAllProducaoSementes();
    }

    
    @GetMapping("/{id}")
    public ResponseEntity<ProducaoSementesDTO> getProducaoSementesById(@PathVariable Integer id) {
        Optional<ProducaoSementesDTO> producao = producaoSementesService.getProducaoSementesById(id);
        return producao.map(ResponseEntity::ok)
                       .orElseGet(() -> ResponseEntity.notFound().build());
    }

    
    @PostMapping
    public ResponseEntity<ProducaoSementesDTO> createProducaoSementes(@RequestBody ProducaoSementes producaoSementes) {
        ProducaoSementesDTO createdProducao = producaoSementesService.createProducaoSementes(producaoSementes);
        return ResponseEntity.status(201).body(createdProducao);
    }

    
    @PutMapping("/{id}")
    public ResponseEntity<ProducaoSementesDTO> updateProducaoSementes(@PathVariable Integer id, @RequestBody ProducaoSementes producaoSementes) {
        Optional<ProducaoSementesDTO> updatedProducao = producaoSementesService.updateProducaoSementes(id, producaoSementes);
        return updatedProducao.map(ResponseEntity::ok)
                              .orElseGet(() -> ResponseEntity.notFound().build());
    }

    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProducaoSementes(@PathVariable Integer id) {
        boolean isDeleted = producaoSementesService.deleteProducaoSementes(id);
        return isDeleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
