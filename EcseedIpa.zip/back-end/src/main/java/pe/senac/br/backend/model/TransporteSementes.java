package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "transporte_sementes")
public class TransporteSementes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "data_entrega_prevista")
    private String dataEntregaPrevista;

    @Column(name = "data_envio")
    private String dataEnvio;

    private String destino;
    private String origem;
    private Integer quantidade;

    @Column(name = "status_transporte")
    private String statusTransporte;


    // 🔵 MANY-TO-MANY com Agricultores
    @ManyToMany
    @JoinTable(
            name = "agricultor_transporte",
            joinColumns = @JoinColumn(name = "id_transporte"),
            inverseJoinColumns = @JoinColumn(name = "cpf_cnpj_agricultor")
    )
    private Set<Agricultores> agricultores = new HashSet<>();


    // 🔵 MANY-TO-MANY com Cooperativas
    @ManyToMany
    @JoinTable(
            name = "cooperativa_transporte",
            joinColumns = @JoinColumn(name = "id_transporte"),
            inverseJoinColumns = @JoinColumn(name = "cnpj_cooperativa")
    )
    private Set<Cooperativa> cooperativas = new HashSet<>();


    // 🔵 MANY-TO-ONE com Transportadora
    @ManyToOne
    @JoinColumn(name = "id_transportadora")
    private Transportadora transportadora;



    // Getters e Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getDataEntregaPrevista() { return dataEntregaPrevista; }
    public void setDataEntregaPrevista(String dataEntregaPrevista) { this.dataEntregaPrevista = dataEntregaPrevista; }

    public String getDataEnvio() { return dataEnvio; }
    public void setDataEnvio(String dataEnvio) { this.dataEnvio = dataEnvio; }

    public String getDestino() { return destino; }
    public void setDestino(String destino) { this.destino = destino; }

    public String getOrigem() { return origem; }
    public void setOrigem(String origem) { this.origem = origem; }

    public Integer getQuantidade() { return quantidade; }
    public void setQuantidade(Integer quantidade) { this.quantidade = quantidade; }

    public String getStatusTransporte() { return statusTransporte; }
    public void setStatusTransporte(String statusTransporte) { this.statusTransporte = statusTransporte; }

    public Set<Agricultores> getAgricultores() { return agricultores; }
    public void setAgricultores(Set<Agricultores> agricultores) { this.agricultores = agricultores; }

    public Set<Cooperativa> getCooperativas() { return cooperativas; }
    public void setCooperativas(Set<Cooperativa> cooperativas) { this.cooperativas = cooperativas; }

    public Transportadora getTransportadora() { return transportadora; }
    public void setTransportadora(Transportadora transportadora) { this.transportadora = transportadora; }
}
