package pe.senac.br.backend.dto;

public class TransportadoraDTO {

    private Integer idTransportadora;
    private String Nome;
    private String CNPJ;
    private String Telefone;
    private String Email;

    // Construtor
    public TransportadoraDTO(Integer idTransportadora, String nome, String cnpj, String telefone, String email) {
        this.idTransportadora = idTransportadora;
        this.Nome = nome;
        this.CNPJ = cnpj;
        this.Telefone = telefone;
        this.Email = email;
    }

    // Getters e Setters
    public Integer getIdTransportadora() {
        return idTransportadora;
    }

    public void setIdTransportadora(Integer idTransportadora) {
        this.idTransportadora = idTransportadora;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
