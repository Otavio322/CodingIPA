package pe.senac.br.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.senac.br.backend.model.Agricultores;

public interface AgricultoresRepository extends JpaRepository<Agricultores, String> {
    Agricultores findByCpfCnpj(String cpfCnpj);  // Método para buscar pelo CPF/CNPJ
}
