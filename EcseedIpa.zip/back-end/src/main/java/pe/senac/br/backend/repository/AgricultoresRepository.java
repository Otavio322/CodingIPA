package pe.senac.br.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.senac.br.backend.model.Agricultores;
import java.util.Optional;

public interface AgricultoresRepository extends JpaRepository<Agricultores, String> {

    Optional<Agricultores> findByCpfCnpj(String cpfCnpj);  // Mudando para Optional
}
