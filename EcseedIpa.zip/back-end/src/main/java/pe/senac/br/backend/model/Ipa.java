package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ipa")
public class Ipa {

    @Id
    @Column(name = "CNPJIPA", length = 18)
    private String cnpj;

    @Column(name = "Nome", nullable = false, length = 60)
    private String nome;

    @Column(name = "Telefone", nullable = false, length = 20)
    private String telefone;

    @Column(name = "Email", nullable = false, length = 60)
    private String email;

    // 1 IPA -> Muitas Cooperativas
    @OneToMany(mappedBy = "ipa", cascade = CascadeType.ALL)
    private List<Cooperativa> cooperativas = new ArrayList<>();

    // 1 IPA -> Muitas entradas de sementes
    @OneToMany(mappedBy = "ipa", cascade = CascadeType.ALL)
    private List<EntradaSementes> entradas = new ArrayList<>();

    // 1 IPA -> 1 endereço
    @OneToOne(mappedBy = "ipa", cascade = CascadeType.ALL)
    private Endereco endereco;

    public Ipa() {}

    public Ipa(String cnpj, String nome, String telefone, String email) {
        this.cnpj = cnpj;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }

    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public List<Cooperativa> getCooperativas() { return cooperativas; }
    public void setCooperativas(List<Cooperativa> cooperativas) { this.cooperativas = cooperativas; }

    public List<EntradaSementes> getEntradas() { return entradas; }
    public void setEntradas(List<EntradaSementes> entradas) { this.entradas = entradas; }

    public Endereco getEndereco() { return endereco; }
    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
        if (endereco != null) {
            endereco.setIpa(this);
        }
    }
}
