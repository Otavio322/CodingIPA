package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.model.EnderecoAgricultores;
import pe.senac.br.backend.service.EnderecoAgricultoresService;

import java.util.List;

@RestController
@RequestMapping("/api/endereco-agricultores")
public class EnderecoAgricultoresController {

    @Autowired
    private EnderecoAgricultoresService service;

    // LISTAR TODOS
    @GetMapping
    public List<EnderecoAgricultores> listarTodos() {
        return service.listarTodos();
    }

    // BUSCAR POR CPF/CNPJ AGRICULTOR
    @GetMapping("/{cpfCnpj}")
    public ResponseEntity<EnderecoAgricultores> buscarPorId(@PathVariable String cpfCnpj) {
        return service.buscarPorId(cpfCnpj)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // SALVAR
    @PostMapping
    public EnderecoAgricultores salvar(@RequestBody EnderecoAgricultores endereco) {
        return service.salvar(endereco);
    }

    // ATUALIZAR
    @PutMapping("/{cpfCnpj}")
    public ResponseEntity<EnderecoAgricultores> atualizar(
            @PathVariable String cpfCnpj,
            @RequestBody EnderecoAgricultores endereco) {

        EnderecoAgricultores atualizado = service.atualizar(cpfCnpj, endereco);

        return (atualizado != null)
                ? ResponseEntity.ok(atualizado)
                : ResponseEntity.notFound().build();
    }

    // DELETAR
    @DeleteMapping("/{cpfCnpj}")
    public ResponseEntity<Void> deletar(@PathVariable String cpfCnpj) {
        boolean deleted = service.deletar(cpfCnpj);
        return deleted ? ResponseEntity.noContent().build()
                       : ResponseEntity.notFound().build();
    }
}
