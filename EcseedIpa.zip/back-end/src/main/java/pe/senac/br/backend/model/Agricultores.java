package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "agricultores")
public class Agricultores {

    @Id
    @Column(name = "CPF_CNPJ", length = 18)
    private String cpfCnpj;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private String telefone;

    @Column(nullable = false)
    private String email;

    @Column
    private Integer idade;

    @Column(name = "tipo_entidade")
    private String tipoEntidade;

    @Column
    private String status;

    @Column
    private String senha; 

    // Relacionamento Many-to-One com Cooperativa
    @ManyToOne
    @JoinColumn(name = "cnpj_cooperativa")
    private Cooperativa cooperativa;

    // Relacionamento Many-to-Many com ProducaoSementes
    @ManyToMany
    @JoinTable(
        name = "agricultor_producao",
        joinColumns = @JoinColumn(name = "cpf_cnpj_agricultor"),
        inverseJoinColumns = @JoinColumn(name = "id_producao_sementes")
    )
    private Set<ProducaoSementes> producoes = new HashSet<>();

    // Getters and Setters
    public String getCpfCnpj() { return cpfCnpj; }
    public void setCpfCnpj(String cpfCnpj) { this.cpfCnpj = cpfCnpj; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Integer getIdade() { return idade; }
    public void setIdade(Integer idade) { this.idade = idade; }

    public String getTipoEntidade() { return tipoEntidade; }
    public void setTipoEntidade(String tipoEntidade) { this.tipoEntidade = tipoEntidade; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public Cooperativa getCooperativa() { return cooperativa; }
    public void setCooperativa(Cooperativa cooperativa) { this.cooperativa = cooperativa; }

    public Set<ProducaoSementes> getProducoes() { return producoes; }
    public void setProducoes(Set<ProducaoSementes> producoes) { this.producoes = producoes; }
}
