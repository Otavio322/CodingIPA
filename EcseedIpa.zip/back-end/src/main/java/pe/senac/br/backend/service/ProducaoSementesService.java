package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.dto.ProducaoSementesDTO;
import pe.senac.br.backend.model.ProducaoSementes;
import pe.senac.br.backend.repository.ProducaoSementesRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProducaoSementesService {

    @Autowired
    private ProducaoSementesRepository producaoSementesRepository;

    public List<ProducaoSementesDTO> getAllProducaoSementes() {
        return producaoSementesRepository.findAll().stream()
                .map(ps -> new ProducaoSementesDTO(
                        ps.getId(), 
                        ps.getTipoSemente(), 
                        ps.getQuantidadeSementes(),
                        ps.getPreco(), 
                        ps.getValidade()))
                .collect(Collectors.toList());
    }

    public Optional<ProducaoSementesDTO> getProducaoSementesById(Integer id) {
        Optional<ProducaoSementes> producaoSementes = producaoSementesRepository.findById(id);
        return producaoSementes.map(ps -> new ProducaoSementesDTO(
                ps.getId(), 
                ps.getTipoSemente(), 
                ps.getQuantidadeSementes(),
                ps.getPreco(), 
                ps.getValidade()));
    }

    public ProducaoSementesDTO createProducaoSementes(ProducaoSementes producaoSementes) {
        ProducaoSementes savedProducao = producaoSementesRepository.save(producaoSementes);
        return new ProducaoSementesDTO(
                savedProducao.getId(), 
                savedProducao.getTipoSemente(),
                savedProducao.getQuantidadeSementes(), 
                savedProducao.getPreco(), 
                savedProducao.getValidade());
    }

    public Optional<ProducaoSementesDTO> updateProducaoSementes(Integer id, ProducaoSementes producaoSementes) {
        if (producaoSementesRepository.existsById(id)) {
            producaoSementes.setId(id);

            ProducaoSementes updatedProducao = producaoSementesRepository.save(producaoSementes);
            return Optional.of(new ProducaoSementesDTO(
                    updatedProducao.getId(), 
                    updatedProducao.getTipoSemente(),
                    updatedProducao.getQuantidadeSementes(), 
                    updatedProducao.getPreco(), 
                    updatedProducao.getValidade()));
        }
        return Optional.empty();
    }

    public boolean deleteProducaoSementes(Integer id) {
        if (producaoSementesRepository.existsById(id)) {
            producaoSementesRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
