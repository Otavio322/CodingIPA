package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import pe.senac.br.backend.dto.LoginRequestDTO;
import pe.senac.br.backend.service.AuthService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private AuthService authService;  // Serviço de autenticação

    @PostMapping("/login")
    public String login(@RequestBody LoginRequestDTO loginRequestDTO) {
        // Cria o token de autenticação
        UsernamePasswordAuthenticationToken authenticationToken = 
            new UsernamePasswordAuthenticationToken(loginRequestDTO.getCpfCnpj(), loginRequestDTO.getSenha());

        // Autentica o usuário
        Authentication authentication = authenticationManager.authenticate(authenticationToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Gera o token JWT
        String token = authService.generateToken(authentication);

        // Retorna o token ou mensagem de sucesso
        return "Autenticação bem-sucedida! Token: " + token;
    }
}
