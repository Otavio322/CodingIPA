package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.LoginRequestDTO;
import pe.senac.br.backend.service.AgricultoresService;
import pe.senac.br.backend.model.Agricultores;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private AgricultoresService agricultoresService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        Optional<Agricultores> agricultorOpt = agricultoresService.findByCpfCnpj(loginRequest.getCpfCnpj());

        if (agricultorOpt.isPresent() && agricultorOpt.get().getSenha().equals(loginRequest.getSenha())) {
            // Aqui você pode adicionar mais lógica, como gerar JWT se necessário
            return ResponseEntity.ok(new LoginResponse(true, "Login bem-sucedido"));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new LoginResponse(false, "Credenciais inválidas"));
        }
    }

    // DTO para o login
    public static class LoginRequest {
        private String cpfCnpj;
        private String senha;

        // Getters e Setters
        public String getCpfCnpj() {
            return cpfCnpj;
        }

        public void setCpfCnpj(String cpfCnpj) {
            this.cpfCnpj = cpfCnpj;
        }

        public String getSenha() {
            return senha;
        }

        public void setSenha(String senha) {
            this.senha = senha;
        }
    }

    // Resposta de login
    public static class LoginResponse {
        private boolean sucesso;
        private String mensagem;

        // Getters e Setters
        public LoginResponse(boolean sucesso, String mensagem) {
            this.sucesso = sucesso;
            this.mensagem = mensagem;
        }

        public boolean isSucesso() {
            return sucesso;
        }

        public void setSucesso(boolean sucesso) {
            this.sucesso = sucesso;
        }

        public String getMensagem() {
            return mensagem;
        }

        public void setMensagem(String mensagem) {
            this.mensagem = mensagem;
        }
    }
}
