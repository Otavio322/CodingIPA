package pe.senac.br.backend.dto;

public class TransporteSementesDTO {

    private Integer agricultorId;
    private Integer cooperativaId;
    private String data;
    private Integer quantidade;
    private String origem;
    private String destino;

    public Integer getAgricultorId() {
        return agricultorId;
    }

    public void setAgricultorId(Integer agricultorId) {
        this.agricultorId = agricultorId;
    }

    public Integer getCooperativaId() {
        return cooperativaId;
    }

    public void setCooperativaId(Integer cooperativaId) {
        this.cooperativaId = cooperativaId;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
}
