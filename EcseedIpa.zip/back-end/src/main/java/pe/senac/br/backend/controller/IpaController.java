package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.IpaDTO;
import pe.senac.br.backend.model.Ipa;
import pe.senac.br.backend.service.IpaService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/ipa")
public class IpaController {

    @Autowired
    private IpaService ipaService;

    @GetMapping
    public List<IpaDTO> getAllIpas() {
        return ipaService.getAllIpas();
    }

    @GetMapping("/{cnpj}")
    public ResponseEntity<IpaDTO> getIpaByCNPJ(@PathVariable String cnpj) {
        Optional<IpaDTO> ipa = ipaService.getIpaByCNPJ(cnpj);
        return ipa.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<IpaDTO> createIpa(@RequestBody Ipa ipa) {
        IpaDTO created = ipaService.createIpa(ipa);
        return ResponseEntity.status(201).body(created);
    }

    @PutMapping("/{cnpj}")
    public ResponseEntity<IpaDTO> updateIpa(@PathVariable String cnpj, @RequestBody Ipa ipa) {
        Optional<IpaDTO> updated = ipaService.updateIpa(cnpj, ipa);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{cnpj}")
    public ResponseEntity<Void> deleteIpa(@PathVariable String cnpj) {
        boolean deleted = ipaService.deleteIpa(cnpj);
        return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
