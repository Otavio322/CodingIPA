package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.repository.UsuarioRepository;

@Service
public class AuthService {

  @Autowired
  private UsuarioRepository repo;

  /**
   * Verifica se há um usuário com esse cpfCnpj e senha.
   * @return true se credenciais válidas, false caso contrário
   */
  public boolean autenticar(String cpfCnpj, String senha) {
    return repo.findByCpfCnpj(cpfCnpj)  // Alterado para encontrar pelo cpfCnpj
               .map(u -> u.getSenha().equals(senha))  // Verifica a senha
               .orElse(false);  // Caso não encontre, retorna false
  }
}
