package pe.senac.br.backend.service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders; 
import io.jsonwebtoken.security.Keys; 
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.security.Key; 
import java.util.Date;

@Service
public class AuthService {

    
    private static final String SECRET_KEY = "SuaChaveSecretaDe512BitsQueNinguemVaiAdivinharParaJWTQueDeveSerLongaEMuitoSegura1234567890"; // 64 bytes para HS512

    
    private Key getSignInKey() {
        byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    // Gera o token JWT 
    public String generateToken(Authentication authentication) {
        long now = System.currentTimeMillis();
        long expirationTime = 3600000; 

        return Jwts.builder()
                .subject(authentication.getName()) 
                .issuedAt(new Date(now))          
                .expiration(new Date(now + expirationTime)) 
                .signWith(getSignInKey())         
                .compact();
    }
}