package pe.senac.br.backend.dto;

import java.time.LocalDate;

public class ProducaoSementesDTO {

    private Integer id;
    private String tipoSemente;
    private Integer quantidadeSementes;
    private Double preco;
    private LocalDate validade;

    // Construtor
    public ProducaoSementesDTO(Integer id, String tipoSemente, Integer quantidadeSementes, Double preco, LocalDate validade) {
        this.id = id;
        this.tipoSemente = tipoSemente;
        this.quantidadeSementes = quantidadeSementes;
        this.preco = preco;
        this.validade = validade;
    }

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipoSemente() {
        return tipoSemente;
    }

    public void setTipoSemente(String tipoSemente) {
        this.tipoSemente = tipoSemente;
    }

    public Integer getQuantidadeSementes() {
        return quantidadeSementes;
    }

    public void setQuantidadeSementes(Integer quantidadeSementes) {
        this.quantidadeSementes = quantidadeSementes;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public LocalDate getValidade() {
        return validade;
    }

    public void setValidade(LocalDate validade) {
        this.validade = validade;
    }
}
