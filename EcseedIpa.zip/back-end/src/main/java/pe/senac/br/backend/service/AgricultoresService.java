package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.dto.AgricultoresDTO;
import pe.senac.br.backend.model.Agricultores;
import pe.senac.br.backend.model.Cooperativa;
import pe.senac.br.backend.repository.AgricultoresRepository;
import pe.senac.br.backend.service.AgricultoresService;
  
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AgricultoresService {

    @Autowired
    private AgricultoresRepository agricultoresRepository;

    public Optional<Agricultores> findByCpfCnpj(String cpfCnpj) {
        return agricultoresRepository.findByCpfCnpj(cpfCnpj);
    }


    // ----------- MÉTODOS AUXILIARES ----------------

    
    private AgricultoresDTO convertToDTO(Agricultores a) {

        String cooperativaCnpj = null;

        if (a.getCooperativa() != null) {
            cooperativaCnpj = a.getCooperativa().getCnpj();
        }

        return new AgricultoresDTO(
                a.getCpfCnpj(),
                a.getNome(),
                a.getIdade(),
                a.getTipoEntidade(),
                a.getTelefone(),
                a.getEmail(),
                a.getStatus(),
                cooperativaCnpj
        );
    }

    // ----------- GET ALL ----------------

    public List<AgricultoresDTO> getAllAgricultores() {
        return agricultoresRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ----------- GET POR CPF/CNPJ ----------------

    public Optional<AgricultoresDTO> getAgricultorByCPF_CNPJ(String cpfCnpj) {
        return agricultoresRepository.findById(cpfCnpj).map(this::convertToDTO);
    }

    // ----------- CREATE ----------------

    public AgricultoresDTO createAgricultor(Agricultores agricultor) {

        if (agricultoresRepository.existsById(agricultor.getCpfCnpj())) {
            throw new IllegalArgumentException("❌ Já existe um agricultor com esse CPF/CNPJ.");
        }

        // Aqui poderia validar se cooperativa existe antes de salvar
        // Mas deixei livre caso você ainda não conectou as FKs

        Agricultores saved = agricultoresRepository.save(agricultor);

        return convertToDTO(saved);
    }

    // ----------- UPDATE ----------------

    public Optional<AgricultoresDTO> updateAgricultor(String cpfCnpj, Agricultores agricultor) {

        if (!agricultoresRepository.existsById(cpfCnpj)) {
            return Optional.empty();
        }

        // Garante que o CPF/CNPJ não seja alterado
        agricultor.setCpfCnpj(cpfCnpj);

        Agricultores updated = agricultoresRepository.save(agricultor);

        return Optional.of(convertToDTO(updated));
    }

    // ----------- DELETE ----------------

    public boolean deleteAgricultor(String cpfCnpj) {

        if (!agricultoresRepository.existsById(cpfCnpj)) {
            return false;
        }

        agricultoresRepository.deleteById(cpfCnpj);

        return true;
    }
}
