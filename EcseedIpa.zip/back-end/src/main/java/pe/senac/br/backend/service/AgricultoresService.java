package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.dto.AgricultoresDTO;
import pe.senac.br.backend.model.Agricultores;
import pe.senac.br.backend.repository.AgricultoresRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AgricultoresService {

    @Autowired
    private AgricultoresRepository agricultoresRepository;

    // Retorna todos os agricultores
    public List<AgricultoresDTO> getAllAgricultores() {
        return agricultoresRepository.findAll().stream()
                .map(agricultor -> new AgricultoresDTO(
                        agricultor.getCpfCnpj(),
                        agricultor.getNome(),
                        agricultor.getIdade(),
                        agricultor.getTipoEntidade(),
                        agricultor.getTelefone(),
                        agricultor.getEmail(),
                        agricultor.getStatus(),
                        agricultor.getCooperativa().getCnpj()
                ))
                .collect(Collectors.toList());
    }

    // Retorna um agricultor específico pelo CPF/CNPJ
    public Optional<AgricultoresDTO> getAgricultorByCPF_CNPJ(String cpfCnpj) {
        return agricultoresRepository.findById(cpfCnpj)
                .map(a -> new AgricultoresDTO(
                        a.getCpfCnpj(),
                        a.getNome(),
                        a.getIdade(),
                        a.getTipoEntidade(),
                        a.getTelefone(),
                        a.getEmail(),
                        a.getStatus(),
                        a.getCooperativa().getCnpj()
                ));
    }

    // Cria um novo agricultor, verifica se já existe no banco
    public AgricultoresDTO createAgricultor(Agricultores agricultor) {
        // Verifica se o agricultor com o mesmo CPF/CNPJ já existe
        if (agricultoresRepository.existsById(agricultor.getCpfCnpj())) {
            throw new IllegalArgumentException("Agricultor já existe com o CPF/CNPJ informado.");
        }

        Agricultores savedAgricultor = agricultoresRepository.save(agricultor);
        return new AgricultoresDTO(
                savedAgricultor.getCpfCnpj(),
                savedAgricultor.getNome(),
                savedAgricultor.getIdade(),
                savedAgricultor.getTipoEntidade(),
                savedAgricultor.getTelefone(),
                savedAgricultor.getEmail(),
                savedAgricultor.getStatus(),
                savedAgricultor.getCooperativa().getCnpj()
        );
    }

    // Atualiza um agricultor, mantendo a integridade de dados
    public Optional<AgricultoresDTO> updateAgricultor(String cpfCnpj, Agricultores agricultor) {
        if (agricultoresRepository.existsById(cpfCnpj)) {
            agricultor.setCpfCnpj(cpfCnpj);  // Garantir que o CPF/CNPJ não seja alterado
            Agricultores updated = agricultoresRepository.save(agricultor);

            return Optional.of(new AgricultoresDTO(
                    updated.getCpfCnpj(),
                    updated.getNome(),
                    updated.getIdade(),
                    updated.getTipoEntidade(),
                    updated.getTelefone(),
                    updated.getEmail(),
                    updated.getStatus(),
                    updated.getCooperativa().getCnpj()
            ));
        }
        return Optional.empty();
    }

    // Deleta um agricultor, retorna se foi deletado com sucesso
    public boolean deleteAgricultor(String cpfCnpj) {
        if (agricultoresRepository.existsById(cpfCnpj)) {
            agricultoresRepository.deleteById(cpfCnpj);
            return true;  // Deletado com sucesso
        }
        return false;  // Não encontrado
    }
}
