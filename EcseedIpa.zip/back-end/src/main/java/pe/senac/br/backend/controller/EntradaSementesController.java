package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.EntradaSementesDTO;
import pe.senac.br.backend.model.EntradaSementes;
import pe.senac.br.backend.service.EntradaSementesService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/entrada-sementes")
public class EntradaSementesController {

    @Autowired
    private EntradaSementesService entradaSementesService;

    // Método GET - Retorna todas as entradas de sementes
    @GetMapping
    public List<EntradaSementesDTO> getAllEntradaSementes() {
        return entradaSementesService.getAllEntradaSementes();
    }

    // Método GET - Retorna uma entrada de sementes pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<EntradaSementesDTO> getEntradaSementesById(@PathVariable Integer id) {
        Optional<EntradaSementesDTO> entrada = entradaSementesService.getEntradaSementesById(id);
        return entrada.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Método POST - Cria uma nova entrada de sementes
    @PostMapping
    public ResponseEntity<EntradaSementesDTO> createEntradaSementes(@RequestBody EntradaSementes entradaSementes) {
        EntradaSementesDTO createdEntrada = entradaSementesService.createEntradaSementes(entradaSementes);
        return ResponseEntity.status(201).body(createdEntrada);
    }

    // Método PUT - Atualiza uma entrada de sementes
    @PutMapping("/{id}")
    public ResponseEntity<EntradaSementesDTO> updateEntradaSementes(@PathVariable Integer id, @RequestBody EntradaSementes entradaSementes) {
        Optional<EntradaSementesDTO> updatedEntrada = entradaSementesService.updateEntradaSementes(id, entradaSementes);
        return updatedEntrada.map(ResponseEntity::ok)
                             .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Método DELETE - Deleta uma entrada de sementes
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEntradaSementes(@PathVariable Integer id) {
        boolean isDeleted = entradaSementesService.deleteEntradaSementes(id);
        return isDeleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}

