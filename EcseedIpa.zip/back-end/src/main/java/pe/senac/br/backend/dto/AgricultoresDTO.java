package pe.senac.br.backend.dto;

public class AgricultoresDTO {

    private String CPF_CNPJ;
    private String Nome;
    private int Idade;
    private String TipoEntidade;
    private String Telefone;
    private String Email;
    private String Status;
    private String Cooperativa_CNPJ;

    // Construtor
    public AgricultoresDTO(String CPF_CNPJ, String Nome, int Idade, String TipoEntidade, String Telefone, 
                            String Email, String Status, String Cooperativa_CNPJ) {
        this.CPF_CNPJ = CPF_CNPJ;
        this.Nome = Nome;
        this.Idade = Idade;
        this.TipoEntidade = TipoEntidade;
        this.Telefone = Telefone;
        this.Email = Email;
        this.Status = Status;
        this.Cooperativa_CNPJ = Cooperativa_CNPJ;
    }

    // Getters e Setters
    public String getCPF_CNPJ() {
        return CPF_CNPJ;
    }

    public void setCPF_CNPJ(String CPF_CNPJ) {
        this.CPF_CNPJ = CPF_CNPJ;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public int getIdade() {
        return Idade;
    }

    public void setIdade(int idade) {
        Idade = idade;
    }

    public String getTipoEntidade() {
        return TipoEntidade;
    }

    public void setTipoEntidade(String tipoEntidade) {
        TipoEntidade = tipoEntidade;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getCooperativa_CNPJ() {
        return Cooperativa_CNPJ;
    }

    public void setCooperativa_CNPJ(String cooperativa_CNPJ) {
        Cooperativa_CNPJ = cooperativa_CNPJ;
    }
}
