package pe.senac.br.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AgricultoresDTO {

    @JsonProperty("CPF_CNPJ")
    private String cpfCnpj;

    @JsonProperty("Nome")
    private String nome;

    @JsonProperty("Idade")
    private int idade;

    @JsonProperty("TipoEntidade")
    private String tipoEntidade;

    @JsonProperty("Telefone")
    private String telefone;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("Cooperativa_CNPJ")
    private String cooperativaCnpj;

    


    // Construtor
    public AgricultoresDTO(String cpfCnpj, String nome, int idade, String tipoEntidade,
                           String telefone, String email, String status, String cooperativaCnpj) {
        this.cpfCnpj = cpfCnpj;
        this.nome = nome;
        this.idade = idade;
        this.tipoEntidade = tipoEntidade;
        this.telefone = telefone;
        this.email = email;
        this.status = status;
        this.cooperativaCnpj = cooperativaCnpj;
    }

    // Getters e Setters
    public String getCpfCnpj() { return cpfCnpj; }
    public void setCpfCnpj(String cpfCnpj) { this.cpfCnpj = cpfCnpj; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getIdade() { return idade; }
    public void setIdade(int idade) { this.idade = idade; }

    public String getTipoEntidade() { return tipoEntidade; }
    public void setTipoEntidade(String tipoEntidade) { this.tipoEntidade = tipoEntidade; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCooperativaCnpj() { return cooperativaCnpj; }
    public void setCooperativaCnpj(String cooperativaCnpj) { this.cooperativaCnpj = cooperativaCnpj; }
}