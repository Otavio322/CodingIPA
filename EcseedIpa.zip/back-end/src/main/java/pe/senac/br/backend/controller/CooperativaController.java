package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.model.Cooperativa;
import pe.senac.br.backend.service.CooperativaService;

import java.util.List;

@RestController
@RequestMapping("/api/cooperativas")
public class CooperativaController {

    @Autowired
    private CooperativaService cooperativaService;

    @GetMapping
    public List<Cooperativa> listarTodas() {
        return cooperativaService.listarTodas();
    }

    @GetMapping("/{cnpj}")
    public ResponseEntity<Cooperativa> buscar(@PathVariable String cnpj) {
        Cooperativa coop = cooperativaService.buscarPorCNPJ(cnpj);

        if (coop == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(coop);
    }

    @PostMapping
    public Cooperativa criar(@RequestBody Cooperativa cooperativa) {
        return cooperativaService.salvar(cooperativa);
    }

    @PutMapping("/{cnpj}")
    public ResponseEntity<Cooperativa> atualizar(
            @PathVariable String cnpj,
            @RequestBody Cooperativa novosDados
    ) {
        Cooperativa atualizado = cooperativaService.atualizar(cnpj, novosDados);

        if (atualizado == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(atualizado);
    }

    @DeleteMapping("/{cnpj}")
    public ResponseEntity<Void> deletar(@PathVariable String cnpj) {
        boolean deletado = cooperativaService.deletar(cnpj);

        if (deletado) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.notFound().build();
    }
}
