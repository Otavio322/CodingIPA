package pe.senac.br.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Transportadora")
public class Transportadora {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_transportadora")   
    private Integer idTransportadora;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private String cnpj;

    private String telefone;

    private String email;

    // GETTERS E SETTERS

    public Integer getIdTransportadora() {
        return idTransportadora;
    }

    public void setIdTransportadora(Integer idTransportadora) {
        this.idTransportadora = idTransportadora;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {   
        return cnpj;
    }

    public void setCnpj(String cnpj) {  
        this.cnpj = cnpj;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
