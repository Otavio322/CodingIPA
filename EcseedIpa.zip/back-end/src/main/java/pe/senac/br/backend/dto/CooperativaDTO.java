package pe.senac.br.backend.dto;



public class CooperativaDTO {

    private String CNPJ;
    private String Nome;
    private String Tipo;
    private String TipoGraos;
    private int QntdGraos;
    private String Email;
    private String Telefone;
    private String ipa_CNPJIPA;

    // Construtor
    public CooperativaDTO(String CNPJ, String Nome, String Tipo, String TipoGraos, int QntdGraos, String Email, String Telefone, String ipa_CNPJIPA) {
        this.CNPJ = CNPJ;
        this.Nome = Nome;
        this.Tipo = Tipo;
        this.TipoGraos = TipoGraos;
        this.QntdGraos = QntdGraos;
        this.Email = Email;
        this.Telefone = Telefone;
        this.ipa_CNPJIPA = ipa_CNPJIPA;
    }

    // Getters e Setters
    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public String getTipoGraos() {
        return TipoGraos;
    }

    public void setTipoGraos(String tipoGraos) {
        TipoGraos = tipoGraos;
    }

    public int getQntdGraos() {
        return QntdGraos;
    }

    public void setQntdGraos(int qntdGraos) {
        QntdGraos = qntdGraos;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getIpa_CNPJIPA() {
        return ipa_CNPJIPA;
    }

    public void setIpa_CNPJIPA(String ipa_CNPJIPA) {
        this.ipa_CNPJIPA = ipa_CNPJIPA;
    }
}
