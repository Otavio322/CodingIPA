package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.model.EnderecoCooperativa;
import pe.senac.br.backend.service.EnderecoCooperativaService;

import java.util.List;

@RestController
@RequestMapping("/api/endereco-cooperativa")
public class EnderecoCooperativaController {

    @Autowired
    private EnderecoCooperativaService service;

    @GetMapping
    public List<EnderecoCooperativa> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<EnderecoCooperativa> buscar(@PathVariable Integer id) {
        EnderecoCooperativa encontrado = service.buscarPorId(id);

        if (encontrado == null)
            return ResponseEntity.notFound().build();

        return ResponseEntity.ok(encontrado);
    }

    @PostMapping
    public EnderecoCooperativa criar(@RequestBody EnderecoCooperativa endereco) {
        return service.salvar(endereco);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EnderecoCooperativa> atualizar(
            @PathVariable Integer id,
            @RequestBody EnderecoCooperativa dados
    ) {
        EnderecoCooperativa atualizado = service.atualizar(id, dados);

        if (atualizado == null)
            return ResponseEntity.notFound().build();

        return ResponseEntity.ok(atualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Integer id) {

        boolean deletou = service.deletar(id);
        if (!deletou)
            return ResponseEntity.notFound().build();

        return ResponseEntity.noContent().build();
    }
}
