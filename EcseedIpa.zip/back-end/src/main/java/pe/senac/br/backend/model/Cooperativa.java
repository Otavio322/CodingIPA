package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.sql.Date;
import java.util.Set;
import java.util.HashSet;

@Entity
@Table(name = "cooperativa")
public class Cooperativa {

    @Id
    @Column(name = "CNPJ", length = 18)
    private String cnpj;

    @Column(name = "Nome")
    private String nome;

    @Column(name = "Tipo")
    private String tipo;

    @Column(name = "Saida")
    private Date saida;

    @Column(name = "Entrada")
    private Date entrada;

    @Column(name = "TipoGraos")
    private String tipoGraos;

    @Column(name = "QntdGraos")
    private Integer qntdGraos;

    @Column(name = "Email")
    private String email;

    @Column(name = "Telefone")
    private String telefone;

    // RELACIONAMENTO COM IPA (MUITAS COOPERATIVAS PARA 1 IPA)
    @ManyToOne
    @JoinColumn(name = "CNPJIPA", nullable = false)
    private Ipa ipa;

    // ENDEREÇO
    @OneToOne(mappedBy = "cooperativa", cascade = CascadeType.ALL, orphanRemoval = true)
    private EnderecoCooperativa enderecoCooperativa;

    // TRANSPORTES (MANY-TO-MANY)
    @ManyToMany
    @JoinTable(
            name = "cooperativa_has_transportes",
            joinColumns = @JoinColumn(name = "Cooperativa_CNPJ"),
            inverseJoinColumns = @JoinColumn(name = "Transporte_idTransporte")
    )
    private Set<TransporteSementes> transportes = new HashSet<>();


    // =====================
    // GETTERS E SETTERS
    // =====================

    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Date getSaida() { return saida; }
    public void setSaida(Date saida) { this.saida = saida; }

    public Date getEntrada() { return entrada; }
    public void setEntrada(Date entrada) { this.entrada = entrada; }

    public String getTipoGraos() { return tipoGraos; }
    public void setTipoGraos(String tipoGraos) { this.tipoGraos = tipoGraos; }

    public Integer getQntdGraos() { return qntdGraos; }
    public void setQntdGraos(Integer qntdGraos) { this.qntdGraos = qntdGraos; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public Ipa getIpa() { return ipa; }
    public void setIpa(Ipa ipa) { this.ipa = ipa; }

    public EnderecoCooperativa getEnderecoCooperativa() { return enderecoCooperativa; }
    public void setEnderecoCooperativa(EnderecoCooperativa enderecoCooperativa) {
        this.enderecoCooperativa = enderecoCooperativa;
        if (enderecoCooperativa != null) {
            enderecoCooperativa.setCooperativa(this);
        }
    }

    public Set<TransporteSementes> getTransportes() { return transportes; }
    public void setTransportes(Set<TransporteSementes> transportes) { this.transportes = transportes; }
}
