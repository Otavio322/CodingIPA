package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "entrada_sementes")
public class EntradaSementes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_entrada_sementes")
    private Integer idEntradaSementes;

    @Column(name = "data_chegada")
    private LocalDateTime dataChegada;

    @Column(name = "quantidade_sementes")
    private Integer quantidadeSementes;

    @Column(name = "tipo_semente")
    private String tipoSemente;

    // FK para IPA
    @Column(name = "ipa_cnpjipa")
    private String ipaCnpjipa;

    @ManyToOne
    @JoinColumn(
            name = "ipa_cnpjipa",
            referencedColumnName = "CNPJIPA",
            insertable = false,   
            updatable = false
    )
    private Ipa ipa; // nome correto da classe


    public Integer getIdEntradaSementes() { return idEntradaSementes; }
    public void setIdEntradaSementes(Integer idEntradaSementes) { this.idEntradaSementes = idEntradaSementes; }

    public LocalDateTime getDataChegada() { return dataChegada; }
    public void setDataChegada(LocalDateTime dataChegada) { this.dataChegada = dataChegada; }

    public Integer getQuantidadeSementes() { return quantidadeSementes; }
    public void setQuantidadeSementes(Integer quantidadeSementes) { this.quantidadeSementes = quantidadeSementes; }

    public String getTipoSemente() { return tipoSemente; }
    public void setTipoSemente(String tipoSemente) { this.tipoSemente = tipoSemente; }

    public String getIpaCnpjipa() { return ipaCnpjipa; }
    public void setIpaCnpjipa(String ipaCnpjipa) { this.ipaCnpjipa = ipaCnpjipa; }

    public Ipa getIpa() { return ipa; }
    public void setIpa(Ipa ipa) { this.ipa = ipa; }
}
